/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { LoadingScreen } from './components/LoadingScreen';
import { Layout } from './components/Layout';
import { HomePage } from './pages/HomePage';
import { WatchtowerSection } from './components/WatchtowerSection';
import { CelestialScrollSection } from './components/CelestialScrollSection';
import { SpiritLensSection, AstroRestorationResponse } from './components/SpiritLensSection';
import { DojoDashboardSection } from './components/DojoDashboardSection';
import { HonorPointsSection } from './components/HonorPointsSection';
import { saveRestoration, loadLatestRestoration } from './utils/imageStore';
import { isCalmMode } from './utils/calmMode';

const INTRO_KEY = 'tsukuyomi_intro_seen';

function shouldShowIntro(): boolean {
  if (typeof window === 'undefined') return false;
  if (isCalmMode()) return false;
  if (window.location.pathname !== '/') return false; // deep links go straight to the page
  try {
    return sessionStorage.getItem(INTRO_KEY) !== '1';
  } catch {
    return false;
  }
}

function AppRoutes() {
  const navigate = useNavigate();
  const [latestRestoration, setLatestRestoration] = useState<AstroRestorationResponse | null>(null);
  const [latestCaptureTitle, setLatestCaptureTitle] = useState<string>('Pillars of Creation (Hubble/JWST)');
  // Becomes true once IndexedDB has been checked for a previously saved restoration
  const [storageReady, setStorageReady] = useState(false);

  // Restore the last Spirit Lens result so the Dojo page still has data after a reload
  useEffect(() => {
    let cancelled = false;
    loadLatestRestoration().then((rec) => {
      if (cancelled) return;
      if (rec) {
        setLatestRestoration(rec.result);
        setLatestCaptureTitle(rec.captureTitle);
      }
      setStorageReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<HomePage />} />
        <Route path="watchtower" element={<WatchtowerSection />} />
        <Route path="scroll" element={<CelestialScrollSection />} />
        <Route
          path="lens"
          element={
            <SpiritLensSection
              onNavigateToDojo={() => navigate('/dojo')}
              storageReady={storageReady}
              initialRestoration={latestRestoration}
              initialCaptureTitle={latestCaptureTitle}
              onRestorationComplete={(result, title) => {
                setLatestRestoration(result);
                setLatestCaptureTitle(title);
                void saveRestoration(result, title);
              }}
            />
          }
        />
        <Route
          path="dojo"
          element={<DojoDashboardSection restorationResult={latestRestoration} captureTitle={latestCaptureTitle} />}
        />
        <Route path="honor" element={<HonorPointsSection />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  const [showIntro, setShowIntro] = useState<boolean>(shouldShowIntro);

  return (
    <BrowserRouter>
      {showIntro && (
        <LoadingScreen
          onLoadingComplete={() => {
            try {
              sessionStorage.setItem(INTRO_KEY, '1');
            } catch {
              /* ignore */
            }
            setShowIntro(false);
          }}
        />
      )}
      <AppRoutes />
    </BrowserRouter>
  );
}
