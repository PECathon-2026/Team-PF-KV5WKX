import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Compass, Scroll, Telescope, LayoutDashboard, Award, Moon, ArrowRight } from 'lucide-react';
import { StarField } from '../components/StarField';
import { FallingLeaves } from '../components/FallingLeaves';
import { CelestialFactOfTheDay } from '../components/common/CelestialFactOfTheDay';
import { getLunarPhase, fetchMoonPhaseApiData, MoonPhaseApiResponse } from '../utils/lunarCycle';
import { playSuzuChime } from '../utils/soundEngine';
import { useCalmMode } from '../utils/calmMode';

const MENU = [
  {
    to: '/watchtower',
    num: '01',
    kanji: '見張台',
    title: 'The Watchtower',
    sub: 'Stargazing Location Finder',
    desc: 'Find dark, clear-sky spots near you ranked by cloud cover, air quality and light pollution.',
    Icon: Compass,
  },
  {
    to: '/scroll',
    num: '02',
    kanji: '天文絵巻',
    title: 'The Celestial Scroll',
    sub: 'Space Event Tracker',
    desc: 'Meteor showers, eclipses, rocket launches and visible ISS passes for your location.',
    Icon: Scroll,
  },
  {
    to: '/lens',
    num: '03',
    kanji: '霊鏡',
    title: 'The Spirit Lens',
    sub: 'Astrophotography Restoration',
    desc: 'Upload a space photo and clean up noise and blur without inventing detail.',
    Icon: Telescope,
  },
  {
    to: '/dojo',
    num: '04',
    kanji: '天文道場',
    title: 'The Dojo Dashboard',
    sub: 'Before / After Visualization',
    desc: 'Compare original and restored images, zoom in, and inspect detected stars and galaxies.',
    Icon: LayoutDashboard,
  },
  {
    to: '/honor',
    num: '05',
    kanji: '武士道',
    title: 'Honor Points',
    sub: 'Progress & Ranks',
    desc: 'Earn ranks for observing events, visiting sites and restoring images.',
    Icon: Award,
  },
];

export const HomePage: React.FC = () => {
  const [calm] = useCalmMode();
  const [apiLunar, setApiLunar] = useState<MoonPhaseApiResponse | null>(null);

  useEffect(() => {
    fetchMoonPhaseApiData()
      .then((res) => setApiLunar(res))
      .catch(() => {
        /* falls back to local SunCalc ephemeris */
      });
  }, []);

  const lunar = getLunarPhase(new Date(), undefined, undefined, apiLunar);

  return (
    <div className="relative">
      {/* Decorative motion only on the home page, and never in calm mode */}
      {!calm && <FallingLeaves density={8} />}

      <section className="relative w-full pt-28 pb-12 px-4 sm:px-6 overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: 'url(/assets/images/rainy_temple_gate.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0F] via-[#0A0A0F]/85 to-[#0A0A0F]/92" />
        {!calm && <StarField starCount={110} />}

        <div className="relative z-10 max-w-3xl mx-auto text-center space-y-5">
          <p className="text-[11px] font-mono tracking-[0.25em] uppercase text-[#D4A84B]">
            月読の門 · Tsukuyomi Watch
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl font-bold tracking-tight text-[#F4EFE3] leading-[1.12]">
            Read the heavens <span className="text-[#D4A84B]">like a warrior.</span>
          </h1>
          <p className="font-sans text-sm sm:text-base text-[#F4EFE3]/80 max-w-xl mx-auto leading-relaxed">
            Find clear skies, track celestial events, and restore deep-space photos. Pick a page below to begin.
          </p>

          {/* Tonight: one quiet line instead of a glowing score widget */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-[#0E1326]/80 border border-[#D4A84B]/30 text-xs font-mono text-[#F4EFE3]/85">
            <Moon className="w-3.5 h-3.5 text-[#D4A84B]" />
            <span>
              Tonight: {lunar.englishName} · {lunar.illuminationExact}% lit · moonrise {lunar.moonriseFormatted}
            </span>
          </div>
        </div>
      </section>

      {/* Main menu */}
      <section aria-labelledby="menu-heading" className="relative max-w-6xl mx-auto px-4 sm:px-8 py-12">
        <h2 id="menu-heading" className="font-serif text-2xl sm:text-3xl font-bold text-[#F4EFE3] mb-6">
          Main menu
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {MENU.map(({ to, num, kanji, title, sub, desc, Icon }) => (
            <Link
              key={to}
              to={to}
              onClick={() => playSuzuChime()}
              className="group flex flex-col justify-between p-5 rounded-xl bg-[#0E1326] border border-[#D4A84B]/25 hover:border-[#D4A84B] focus-visible:border-[#D4A84B] focus-visible:outline-none transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <Icon className="w-6 h-6 text-[#D4A84B]" aria-hidden="true" />
                  <span className="font-mono text-xs text-[#8E9BB5]">
                    {num} · <span className="font-kanji">{kanji}</span>
                  </span>
                </div>
                <h3 className="font-serif text-xl font-bold text-[#F4EFE3]">{title}</h3>
                <p className="font-mono text-[11px] uppercase tracking-wider text-[#D4A84B]/80 mt-0.5">{sub}</p>
                <p className="font-sans text-sm text-[#8E9BB5] mt-3 leading-relaxed">{desc}</p>
              </div>
              <span className="mt-5 inline-flex items-center gap-1.5 text-sm font-semibold text-[#F4EFE3] group-hover:text-[#D4A84B] transition-colors">
                Open <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      <section className="relative max-w-4xl mx-auto px-4 sm:px-8 pb-16">
        <CelestialFactOfTheDay />
      </section>
    </div>
  );
};
